import { ConnectivityService } from './connectivity.service';

export { ConnectivityService };

export const CONNECTIVITY_PROVIDERS: any[] = [
  ConnectivityService
];
