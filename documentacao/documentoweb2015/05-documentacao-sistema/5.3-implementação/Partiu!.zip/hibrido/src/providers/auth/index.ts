
import { FirebaseAuthService } from './firebase-auth.service';

export { FirebaseAuthService };

export const AUTH_PROVIDERS: any[] = [
  FirebaseAuthService
];
