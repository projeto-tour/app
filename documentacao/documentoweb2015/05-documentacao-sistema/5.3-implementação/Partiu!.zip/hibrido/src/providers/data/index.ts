export * from './agenda.service';
export * from './menu-data.service';
export * from './notificacao.service';
export * from './ponto-interesse.service';
export * from './preferencia-usuario.service';
export * from './rota.service';
export * from './tipo-agenda.service';
export * from './tipo-ponto-interesse.service';
export * from './transporte.service';
export * from './tutorial-data.service';
export * from './usuario.service';

// import { AgendaService } from './agenda.service';
// import { MenuDataService } from './menu-data.service';
// import { NotificacaoService } from './notificacao.service';
// import { PontoInteresseService } from './ponto-interesse.service';
// import { PreferenciaUsuarioService } from './preferencia-usuario.service';
// import { RotaService } from './rota.service';
// import { TipoAgendaService } from './tipo-agenda.service';
// import { TipoPontoInteresseService } from './tipo-ponto-interesse.service';
// import { TransporteService } from './transporte.service';
// import { TutorialDataService } from './tutorial-data.service';
// import { UsuarioService } from './usuario.service';

// export {
//   AgendaService,
//   MenuDataService,
//   NotificacaoService,
//   PontoInteresseService,
//   PreferenciaUsuarioService,
//   RotaService,
//   TipoAgendaService,
//   TipoPontoInteresseService,
//   TransporteService,
//   TutorialDataService,
//   UsuarioService
// };

// export const DATA_PROVIDERS: any[] = [
//   AgendaService,
//   MenuDataService,
//   NotificacaoService,
//   PontoInteresseService,
//   PreferenciaUsuarioService,
//   RotaService,
//   TipoAgendaService,
//   TipoPontoInteresseService,
//   TransporteService,
//   TutorialDataService,
//   UsuarioService
// ];
