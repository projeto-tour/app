export { AgendaPage } from './agenda.component';
export { AgendaDetailPage } from './agenda-detail.component';

