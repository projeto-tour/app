export { PrincipalPage } from './principal.component';
