export { DesenvolvimentoPage } from './desenvolvimento.component';
