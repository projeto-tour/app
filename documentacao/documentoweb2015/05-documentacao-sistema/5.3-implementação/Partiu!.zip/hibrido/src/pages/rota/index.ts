export { RotaPage } from './rota.component';
export { RotaDetailPage } from './rota-detail.component';

