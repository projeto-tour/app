export { BagagemPage } from './bagagem.component';
