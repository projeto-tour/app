export { PreferenciaPage } from './preferencia.component';
