export { HistoricoPage } from './historico.component';
export { HistoricoListPage } from './historico-list.component';
