export { CompartilharPage } from './compartilhar.component';
