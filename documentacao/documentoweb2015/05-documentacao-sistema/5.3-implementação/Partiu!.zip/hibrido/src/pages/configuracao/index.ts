export { ConfiguracaoPage } from './configuracao.component';
