export { NotificacaoPage } from './notificacao.component';
