export { PontoInteressePage } from './ponto-interesse.component';
