export interface ITutorial {
    index: number;
    titulo: string;
    descricao: string;
    url: string;
}
