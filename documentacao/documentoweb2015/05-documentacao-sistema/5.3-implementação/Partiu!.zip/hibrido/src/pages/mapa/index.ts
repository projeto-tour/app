export { MapaPage } from './mapa.component';
