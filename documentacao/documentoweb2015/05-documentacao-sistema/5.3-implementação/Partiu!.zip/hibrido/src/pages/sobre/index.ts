export { SobrePage } from './sobre.component';
