export * from './caracteristica-tipo-ponto-interesse.component';
