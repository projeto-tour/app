export * from './avaliacao.component';
