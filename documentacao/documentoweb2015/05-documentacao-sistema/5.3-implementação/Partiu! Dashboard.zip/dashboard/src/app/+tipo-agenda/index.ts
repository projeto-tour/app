export * from './tipo-agenda.component';
