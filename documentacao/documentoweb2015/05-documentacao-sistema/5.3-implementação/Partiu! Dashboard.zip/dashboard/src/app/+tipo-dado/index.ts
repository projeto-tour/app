export * from './tipo-dado.component';
