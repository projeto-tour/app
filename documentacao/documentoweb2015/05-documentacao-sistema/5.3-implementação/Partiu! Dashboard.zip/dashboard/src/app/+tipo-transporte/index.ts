export * from './tipo-transporte.component';
