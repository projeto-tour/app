export * from './tipo-ponto-interesse.component';
