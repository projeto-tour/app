export * from './caracteristica.component';
