export * from './rating.component';
