document.addEventListener('WebComponentsReady', function() {
  require('./main.ts');
});
